﻿using System;

namespace Ques2
{
    class ParentClass
    {
        public ParentClass()
        {
            Console.WriteLine("Default Parent Cons");
        }

        public ParentClass(String name)
        {
            Console.WriteLine(name);
        }
    }
    class ChildClass:ParentClass
    {
        public ChildClass()
        {
            Console.WriteLine("Default child cons");
        }

        public ChildClass(String text)
        {
            Console.WriteLine(text);
        }

        public static void Main()
        {
            String name = "Parameterized parent cons";
            String text = "Parameterized child cons";
            ChildClass ob = new ChildClass();
            ParentClass ob2 = new ParentClass(name);
            ChildClass ob3 = new ChildClass(text);
            Console.ReadLine();
        }

       
    }
}
