﻿using System;

namespace Ques1
{
    public class BaseClass              //Parent class
    {
        public virtual void show()
        {
            Console.WriteLine("I'm a Parent Class.");
        }
        public virtual void display()
        {
            Console.WriteLine("I'm a Parent display.");
        }
    }
    public class DerivedClass : BaseClass             //child class
    {
        public override void show()                //override keyword
        {
            Console.WriteLine("I'm a Child Class.");
        }
        public new void display()                    //new keyword to hide childclass method
        {
            Console.WriteLine("I'm a Child display.");
        }
        public static void Main()
        {
            BaseClass parent = new DerivedClass();         //upcasting
            parent.show();
            parent.display();
            Console.ReadLine();
        }
        
    }
    
}